package com.ipl.jwtauthentication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.security.services.PlayerService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/players")
public class PlayerController {
	
	@Autowired(required=true)
	PlayerService playerService;
	
	@GetMapping("/all")
	public List<Player> findAll(){
		List<Player> players = playerService.findAll();
		System.out.println(" ---> "+players.size());
		return players;
	}
//	@Autowired
//	PlayerService playerService;
//	
//	
//	@GetMapping("/user")
//	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
//	public ResponseEntity<Iterable<Player>> findAll() {
//	  
//	  System.out.println("in find all");
//	  
//	  Iterable<Player> players = playerService.findAll();
//	  return ResponseEntity.ok(players);
//	}
	
	
	/*
	 * @GetMapping("/player/{pid}") public Player findById(@PathVariable int
	 * playerId) { return service.findById(playerId); }
	 * 
	 * @PostMapping("/player/save") public String save(@RequestBody Player player) {
	 * return service.save(player); }
	 * 
	 * @PutMapping(
	 * "/player/update/{playerId}/{selectedTeam}/{strikeRate}/{average}/{playerRank}/{experience}")
	 * public String update(@PathVariable int playerId,@PathVariable String
	 * selectedTeam,@PathVariable double strikeRate,@PathVariable double
	 * average,@PathVariable int playerRank,@PathVariable int experience) { return
	 * service.update(playerId,selectedTeam,
	 * strikeRate,average,playerRank,experience); }
	 * 
	 * @DeleteMapping("/player/delete/{playerId}") public String
	 * deleteById(@PathVariable int playerId) { return service.deleteById(playerId);
	 * }
	 */
	
	
//	@DeleteMapping("/delete/{playerId}")
//	public String deleteById(@PathVariable long playerId) 
//	{ 
//		return service.deleteById(playerId);
//	 }
//
//	@DeleteMapping("/delete/{playerId}")
//	public String deleteById(@PathVariable long playerId) 
//	{ 
//		return playerService.deleteById(playerId);
//	 }
	
	@PostMapping({"user/playerregister/create"})
	public Player save(@RequestBody Player player) {
		System.out.println(player);
		return playerService.save(new Player(player.getPlayerId(),player.getPlayerName(),player.getPlayerAddress(),player.getDateOfBirth(),player.getMobileNo(),player.getEmail(),player.getMatchesPlayed(),player.getPlayerRole(),player.getMajorTeams(),player.getStrikeRate(),player.getAverage(),player.getExperience(),player.getPlayerRank(),player.getSelectedTeam()));
	}
	
//	@DeleteMapping({"/delete/{playerId}"})
//	public ResponseEntity<String> deletePlayerById(@PathVariable("playerId") long playerId){
//		System.out.println("deleting player -> "+playerId);
//		service.deleteById(playerId);
//		return ResponseEntity.ok("deleted "+playerId); 
//	}
	
	@PutMapping("user/update/{playerId}")
	public ResponseEntity<Player> updatePlayer(@PathVariable("playerId") long playerId,@RequestBody Player player) {
		System.out.println("method called" );

		Optional<Player> playerData = playerService.findById(playerId);

		if (playerData.isPresent()) {
			Player player1 = playerData.get();
			player1.setPlayerName(player.getPlayerName());
			player1.setSelectedTeam(player.getSelectedTeam());
			
			
			return new ResponseEntity<>(playerService.save(player1), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	
	
	
	
	@PutMapping("user/updatePlayerRole/{playerId}")
	public ResponseEntity<Player> updatePlayerRole(@PathVariable("playerId") long playerId,@RequestBody Player player) {
		System.out.println("method called" );

		Optional<Player> playerData = playerService.findById(playerId);

		if (playerData.isPresent()) {
			Player player1 = playerData.get();
			player1.setPlayerRole(player.getPlayerRole());
			
			
			return new ResponseEntity<>(playerService.save(player1), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
}
