package com.ipl.jwtauthentication.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Owner;
import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Team;
import com.ipl.jwtauthentication.model.User;
import com.ipl.jwtauthentication.repository.UserRepository;
import com.ipl.jwtauthentication.security.services.PlayerService;
import com.ipl.jwtauthentication.security.services.UserServiceDetails;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/admin/users")
public class UserController {

	
	
	@Autowired(required=true)
	UserServiceDetails userServiceDetails;
	
	@GetMapping("/all")
	public List<User> findAll(){
		List<User> users = userServiceDetails.findAll();
		System.out.println(" ---> "+users.size());
		return users;
	}
}
