package com.ipl.jwtauthentication.model;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="players")
public class Player {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long playerId;
	
	private String playerName;
	
	private String playerAddress;
	private LocalDate dateOfBirth;
	private long mobileNo;
	private String email;
	private int matchesPlayed;
	private String playerRole;
	private String majorTeams;
	private double strikeRate;
	private double average;
	private int experience;
	private int playerRank;
	private String selectedTeam;
	public Player() {
		super();
	}
	public Player(long playerId, String playerName, String playerAddress, LocalDate dateOfBirth, long mobileNo,
			String email, int matchesPlayed, String playerRole, String majorTeams, double strikeRate, double average,
			int experience, int playerRank, String selectedTeam) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerAddress = playerAddress;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.email = email;
		this.matchesPlayed = matchesPlayed;
		this.playerRole = playerRole;
		this.majorTeams = majorTeams;
		this.strikeRate = strikeRate;
		this.average = average;
		this.experience = experience;
		this.playerRank = playerRank;
		this.selectedTeam = selectedTeam;
	}
	public long getPlayerId() {
		return playerId;
	}
	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getPlayerAddress() {
		return playerAddress;
	}
	public void setPlayerAddress(String playerAddress) {
		this.playerAddress = playerAddress;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMatchesPlayed() {
		return matchesPlayed;
	}
	public void setMatchesPlayed(int matchesPlayed) {
		this.matchesPlayed = matchesPlayed;
	}
	public String getPlayerRole() {
		return playerRole;
	}
	public void setPlayerRole(String playerRole) {
		this.playerRole = playerRole;
	}
	public String getMajorTeams() {
		return majorTeams;
	}
	public void setMajorTeams(String majorTeams) {
		this.majorTeams = majorTeams;
	}
	public double getStrikeRate() {
		return strikeRate;
	}
	public void setStrikeRate(double strikeRate) {
		this.strikeRate = strikeRate;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getPlayerRank() {
		return playerRank;
	}
	public void setPlayerRank(int playerRank) {
		this.playerRank = playerRank;
	}
	public String getSelectedTeam() {
		return selectedTeam;
	}
	public void setSelectedTeam(String selectedTeam) {
		this.selectedTeam = selectedTeam;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (playerId ^ (playerId >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Player other = (Player) obj;
		if (playerId != other.playerId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName + ", playerAddress=" + playerAddress
				+ ", dateOfBirth=" + dateOfBirth + ", mobileNo=" + mobileNo + ", email=" + email + ", matchesPlayed="
				+ matchesPlayed + ", playerRole=" + playerRole + ", majorTeams=" + majorTeams + ", strikeRate="
				+ strikeRate + ", average=" + average + ", experience=" + experience + ", playerRank=" + playerRank
				+ ", selectedTeam=" + selectedTeam + "]";
	}


	
}
