package com.ipl.jwtauthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Role;
import com.ipl.jwtauthentication.model.SelectedPlayers;

@Repository
public interface SelectedPlayerRepository extends JpaRepository<SelectedPlayers, Long> {
	
	SelectedPlayers save(SelectedPlayers player);
}
