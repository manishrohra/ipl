package com.ipl.jwtauthentication.security.services;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.model.Team;
import com.ipl.jwtauthentication.repository.IPlayerRepository;
import com.ipl.jwtauthentication.repository.TeamRepository;
@Service
public interface TeamDetailService extends TeamRepository{

	
	List<Team>	findAll();

	Team save(Team team);


}
