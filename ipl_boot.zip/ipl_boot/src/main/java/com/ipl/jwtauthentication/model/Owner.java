package com.ipl.jwtauthentication.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "owners")
public class Owner {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;

    @NotBlank
    @Size(min=3, max = 50)
    private String ownerName;

    @NotBlank
    @Size(min=3, max = 50)
    private String ownerEmail;
    
    @NotBlank
    @Size(min=3, max = 50)
    private String ownerAddress;
    
    
    @NotBlank
    @Size(min=3, max = 50)
	private long ownerMobileNo;
    
    @NotBlank
    @Size(min=3, max = 50)
    private String ownerTeamName;
    
   

	public Owner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Owner(Long ownerId, @NotBlank @Size(min = 3, max = 50) String ownerName,
			@NotBlank @Size(min = 3, max = 50) String ownerEmail,
			@NotBlank @Size(min = 3, max = 50) String ownerAddress,
			@NotBlank @Size(min = 3, max = 50) long ownerMobileNo,
			@NotBlank @Size(min = 3, max = 50) String ownerTeamName) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownerEmail = ownerEmail;
		this.ownerAddress = ownerAddress;
		this.ownerMobileNo = ownerMobileNo;
		this.ownerTeamName = ownerTeamName;
	}

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerAddress() {
		return ownerAddress;
	}

	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}

	public long getOwnerMobileNo() {
		return ownerMobileNo;
	}

	public void setOwnerMobileNo(long ownerMobileNo) {
		this.ownerMobileNo = ownerMobileNo;
	}

	public String getOwnerTeamName() {
		return ownerTeamName;
	}

	public void setOwnerTeamName(String ownerTeamName) {
		this.ownerTeamName = ownerTeamName;
	}

	

	@Override
	public String toString() {
		return "Owner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerEmail=" + ownerEmail
				+ ", ownerAddress=" + ownerAddress + ", ownerMobileNo=" + ownerMobileNo + ", ownerTeamName="
				+ ownerTeamName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ownerId == null) ? 0 : ownerId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Owner other = (Owner) obj;
		if (ownerId == null) {
			if (other.ownerId != null)
				return false;
		} else if (!ownerId.equals(other.ownerId))
			return false;
		return true;
	}
}
