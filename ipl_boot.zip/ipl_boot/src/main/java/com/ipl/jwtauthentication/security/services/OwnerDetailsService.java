package com.ipl.jwtauthentication.security.services;



import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.ipl.jwtauthentication.model.Owner;

public interface OwnerDetailsService extends UserDetailsService{
	
	
	List<Owner> findAll();

	
}
