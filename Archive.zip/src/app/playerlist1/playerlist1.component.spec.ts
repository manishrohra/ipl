import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Playerlist1Component } from './playerlist1.component';

describe('Playerlist1Component', () => {
  let component: Playerlist1Component;
  let fixture: ComponentFixture<Playerlist1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Playerlist1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Playerlist1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
