import { Component, OnInit } from '@angular/core';
import { Team } from '../pm/team';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-team-registered',
  templateUrl: './team-registered.component.html',
  styleUrls: ['./team-registered.component.css']
})
export class TeamRegisteredComponent implements OnInit {
  team:Team=new Team();
  
  
  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    this.userService.getTeamBoard().subscribe(
      data => {
        this.team = data;
      }
    )}

}
