export class Player{
    playerId:number;
    playerName:string;
    playerAddress:string;
    dateOfBirth:Date;
    mobileNo:number;
    email:string;
    matchesPlayed:number;
    playerRole:string;
    majorTeams:string;
    strikeRate:number;
    average:number;
    experience:number;
    playerRank:number;
    selectedTeam:string;
}