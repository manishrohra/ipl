export class Users{
    id:number;
    name:string;
    email:string;
    username:string;
}