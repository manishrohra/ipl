export class Teams{
    teamId:number;
    teamName:string;
}