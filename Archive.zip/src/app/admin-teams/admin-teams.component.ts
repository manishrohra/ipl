import { Component, OnInit } from '@angular/core';
import { Team } from '../pm/team';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-teams',
  templateUrl: './admin-teams.component.html',
  styleUrls: ['./admin-teams.component.css']
})
export class AdminTeamsComponent implements OnInit {
  team:Team=new Team();

  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    this.userService.getTeamBoard().subscribe(
      data => {
        this.team = data;
      }
    )}

}
