import { Component, OnInit } from '@angular/core';
import { Roles } from '../admin/roles';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminregisterroles',
  templateUrl: './adminregisterroles.component.html',
  styleUrls: ['./adminregisterroles.component.css']
})
export class AdminregisterrolesComponent implements OnInit {
  role: Roles=new Roles();
  submitted = false;

  board: any;
  errorMessage: string;

  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    
  }

  newPlayer():void{
    this.submitted=false;
    this.role = new Roles();
  }

  save(){
    if(!this.submitted){
      this.userService.createRole(this.role).subscribe(role => {
        console.log(role);
        this.submitted = false;
      },
      error => {
        console.log(error);
        this.submitted = false;
      });
    }
  }

  submit(){
    this.save();
    this.submitted = true;
  }

}
