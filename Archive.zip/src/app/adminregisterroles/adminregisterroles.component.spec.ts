import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminregisterrolesComponent } from './adminregisterroles.component';

describe('AdminregisterrolesComponent', () => {
  let component: AdminregisterrolesComponent;
  let fixture: ComponentFixture<AdminregisterrolesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminregisterrolesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminregisterrolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
