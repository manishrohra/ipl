import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-playeredit1',
  templateUrl: './playeredit1.component.html',
  styleUrls: ['./playeredit1.component.css']
})
export class Playeredit1Component implements OnInit {
  player: Player=new Player();
  submitted = false;

  board: Object;
  errorMessage: string;

  constructor(private userService: UserService) { }

  ngOnInit() {
  }


  updatePlayerRole(playerId:number,playerRole:string){
    console.log("player edit");
    
        this.userService.updatePlayerRole(this.player.playerId,
          {playerId:playerId,playerRole:playerRole})
          .subscribe(
            data => {
              console.log(data);
              this.player = data as Player;
            },
            error => console.log(error));
      }
}
