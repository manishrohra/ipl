import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Player } from '../player';
import { Router } from '@angular/router';
import { Teams } from '../admin/teams';
import { Team } from './team';

@Component({
  selector: 'app-pm',
  templateUrl: './pm.component.html',
  styleUrls: ['./pm.component.css']
})
export class PmComponent implements OnInit {
  player:Player;
  players:Object;
  owners: Object;
  submitted = false;
  team:Team=new Team();

  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {}
  //   this.userService.getPMBoard().subscribe(
  //     data => {
  //       this.board = data;
  //     },
  //     error => {
  //       this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
  //     }
  //   );

  //   this.userService.getOwnerBoard().subscribe(
  //     data => {
  //       this.owners = data;
  //     },
  //     error => {
  //       this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
  //     }
  //   );

  //   this.userService.getPmUserBoard().subscribe(
  //     data => {
  //       this.players = data;
  //     },
  //     error => {
  //       this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
  //     }
  //   );
  // }






  newTeam():void{
    this.submitted=false;
    this.team = new Team();
  }

  save(){
    if(!this.submitted){
      this.userService.createTeam(this.team).subscribe(team => {
        console.log(team);
        this.submitted = false;
      },
      error => {
        console.log(error);
        this.submitted = false;
      });
    }
  }

  submit(){
    this.save();
    this.submitted = true;
    // this.router.navigate(['/pm']);
  }

}
