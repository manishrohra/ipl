import { Component, OnInit } from '@angular/core';
import { trigger, transition, style, animate, group, query } from '@angular/animations';

@Component({
  selector: 'app-design',
  templateUrl: './design.component.html',
  styleUrls: ['./design.component.css'],
  
})
export class DesignComponent implements OnInit {
  imageObject: Array<object> = [{
    image: 'assets/images/download1.jfif',
    thumbImage: 'assets/images/download1.jfif',
    alt: 'alt of image',
    title: 'Pizza Marinare'
}, {
    image: 'assets/images/download2.jfif',
    thumbImage: 'assets/images/download2.jfif',
    title: 'Pizza Margherita', //Optional: You can use this key if want to show image with title
    alt: 'Image alt' //Optional: You can use this key if want to show image with alt
},
{
  image: 'assets/images/download4.jfif',
  thumbImage: 'assets/images/download3.jfif',
  title: 'Hawaiian Pizza', //Optional: You can use this key if want to show image with title
  alt: 'Image alt' //Optional: You can use this key if want to show image with alt
},
{
  image: 'assets/images/original.jpg',
  thumbImage: 'assets/images/original.jpg',
  title: 'Italian pizza', //Optional: You can use this key if want to show image with title
  alt: 'Image alt' //Optional: You can use this key if want to show image with alt
}
,
{
  image: 'assets/images/download9.jpg',
  thumbImage: 'assets/images/download9.jpg',
  title: 'Thin Crust Pizza', //Optional: You can use this key if want to show image with title
  alt: 'Image alt' //Optional: You can use this key if want to show image with alt
},
{
  image: 'assets/images/Pizza.jpg',
  thumbImage: 'assets/images/Pizza.jpg',
  title: 'Peppy Paneer', //Optional: You can use this key if want to show image with title
  alt: 'Image alt' //Optional: You can use this key if want to show image with alt
},

];
// images = [  
//   { img: "/assets/images/image.jpg" },  
//   { img: "/assets/images/image.jpg" },  
//   { img: "/assets/images/image.jpg" },  
//   { img: "/assets/images/image.jpg" },  
//   { img: "../assets/images/5.jpg" },  
//   { img: "../assets/images/6.jpg" },  
//   { img: "../assets/images/7.jpg" },  
//   { img: "../assets/images/8.jpg" },  
//   { img: "../assets/images/9.jpg" },  
// ];  
// slideConfig = {  
//   "slidesToShow": 3,  
//   "slidesToScroll": 3,  
//   "dots": true,  
//   "infinite": true  
// };  


  constructor() { }

  ngOnInit() {
  }

}
