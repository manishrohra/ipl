import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { PmComponent } from './pm/pm.component';

import { httpInterceptorProviders } from './auth/auth-interceptor';
import { PlayereditComponent } from './player/playeredit/playeredit.component';
import { PlayerlistComponent } from './player/playerlist/playerlist.component';
import { PlayerregisterComponent } from './player/playerregister/playerregister.component';
import { OwnerComponent } from './owner/owner.component';
import { PlayerregistercskComponent } from './player/playerregistercsk/playerregistercsk.component';
import { TeamRegisteredComponent } from './team-registered/team-registered.component';
import { Playerlist1Component } from './playerlist1/playerlist1.component';
import { Playeredit1Component } from './playeredit1/playeredit1.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminTeamsComponent } from './admin-teams/admin-teams.component';
import { AdminPlayersComponent } from './admin-players/admin-players.component';
import { AdminregisterrolesComponent } from './adminregisterroles/adminregisterroles.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    RegisterComponent,
    HomeComponent,
    AdminComponent,
    PmComponent,
    OwnerComponent,
    PlayereditComponent,
    PlayerlistComponent,
    PlayerregisterComponent,
    PlayerregistercskComponent,
    TeamRegisteredComponent,
    Playerlist1Component,
    Playeredit1Component,
    AdminUsersComponent,
    AdminTeamsComponent,
    AdminPlayersComponent,
    AdminregisterrolesComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
