import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Player } from 'src/app/player';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-playerregister',
  templateUrl: './playerregister.component.html',
  styleUrls: ['./playerregister.component.css']
})
export class PlayerregisterComponent implements OnInit {

  player: Player=new Player();
  submitted = false;

  board: any;
  errorMessage: string;

  constructor(private userService: UserService,private router:Router) { }

  ngOnInit() {
    this.userService.getUserBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }

  newPlayer():void{
    this.submitted=false;
    this.player = new Player();
  }

  save(){
    if(!this.submitted){
      this.userService.createPlayer(this.player).subscribe(player => {
        console.log(player);
        this.submitted = false;
      },
      error => {
        console.log(error);
        this.submitted = false;
      });
    }
  }

  submit(){
    this.save();
    this.submitted = true;
  }
}
