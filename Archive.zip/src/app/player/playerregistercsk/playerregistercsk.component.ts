import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playerregistercsk',
  templateUrl: './playerregistercsk.component.html',
  styleUrls: ['./playerregistercsk.component.css']
})
export class PlayerregistercskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
