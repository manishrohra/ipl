import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { Observable } from 'rxjs';
import { UserService } from 'src/app/services/user.service';
import { Player } from 'src/app/player';

@Component({
  selector: 'app-playerlist',
  templateUrl: './playerlist.component.html',
  styleUrls: ['./playerlist.component.css']
})
export class PlayerlistComponent implements OnInit {

  constructor(private userService: UserService,private router:Router) { }
  player:Player;
  board: any;
  errorMessage: string;

  players: Observable<Player[]>;

  ngOnInit() {

    this.userService.getUserBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }

  deletePlayer(playerId: any) {
    this.userService.deletePlayer(playerId)
      .subscribe(
        data => {
          console.log(data);
          // this.reloadData();
        },
        error => console.log(error));
  }
  // reloadData() {
  //   this.player
  //    = this.userService.getUserBoard();
  // }
}