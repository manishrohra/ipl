import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { PmComponent } from './pm/pm.component';
import { AdminComponent } from './admin/admin.component';
import { PlayereditComponent } from './player/playeredit/playeredit.component';
import { PlayerregisterComponent } from './player/playerregister/playerregister.component';
import { PlayerlistComponent } from './player/playerlist/playerlist.component';
import { OwnerComponent } from './owner/owner.component';
import { PlayerregistercskComponent } from './player/playerregistercsk/playerregistercsk.component';
import { TeamRegisteredComponent } from './team-registered/team-registered.component';
import { Playerlist1Component } from './playerlist1/playerlist1.component';
import { Playeredit1Component } from './playeredit1/playeredit1.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminTeamsComponent } from './admin-teams/admin-teams.component';
import { AdminPlayersComponent } from './admin-players/admin-players.component';
import { AdminregisterrolesComponent } from './adminregisterroles/adminregisterroles.component';

const routes: Routes = [
    {
        path: 'home',
        component: HomeComponent
    },
    {
        path: 'user',
        component: UserComponent
    },
    {
        path: 'owner',
        component: OwnerComponent
    },
    {
        path: 'pm',
        component: PmComponent
    },
    {
        path: 'admin',
        component: AdminComponent
    },
    {
        path: 'auth/login',
        component: LoginComponent
    },
    {
        path: 'signup',
        component: RegisterComponent
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    }, {
        path: 'user/playeredit',
        component: PlayereditComponent
    },
    {
        path: 'user/playerregister',
        component:PlayerregisterComponent
    },
    {
        path: 'user/playerregistercsk',
        component:PlayerregistercskComponent
    },
    {
        path: 'user/playerlist',
        component:PlayerlistComponent

    },
    {
        path: 'pm/teamregistered',
        component:TeamRegisteredComponent

    },
    {
        path: 'pm/teamregistered/playerlist',
        component:Playerlist1Component

    },
    {
        path: 'pm/teamregistered/playerlist/playeredit',
        component:Playeredit1Component

    },
    {
        path: 'adminUsers',
        component:AdminUsersComponent

    },
    {
        path: 'adminTeams',
        component:AdminTeamsComponent

    },
    {
        path: 'adminPlayers',
        component:AdminPlayersComponent

    },
    {
        path: 'adminregisterroles',
        component:AdminregisterrolesComponent

    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
