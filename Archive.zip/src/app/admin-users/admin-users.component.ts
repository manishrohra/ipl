import { Component, OnInit } from '@angular/core';
import { Users } from '../admin/users';
import { UserService } from '../services/user.service';
import { Roles } from '../admin/roles';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css']
})
export class AdminUsersComponent implements OnInit {
  users: Users;
  roles:Roles;
  errorMessage: string;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getAdminUsersBoard1().subscribe(
      data => {
        this.users = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );

    this.userService.getAdminRolesBoard().subscribe(
      data => {
        this.roles = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }

}
